# Paso a paso para publicar — usuario `orozcoig`

Todo con sus datos ya puestos. Unos 20 minutos.

Al final va a tener un enlace que puede abrir usted o enviarle a alguien, y que
muestra la planta ficticia de **Medellín, 500 kWp DC / 400 kW AC**, con su
generación pronosticada contra la real.

---

## PARTE A — En su PC

### A1. Bajar los archivos a una carpeta

Descargue todos los archivos del proyecto. Cree una carpeta llamada
**`pronostico-solar`** y deje adentro esta estructura exacta:

```
pronostico-solar/
├── .github/workflows/banco.yml
├── .gitignore
├── banco/        ← 23 archivos .py
├── tests/        ← test_banco.py
├── colab/        ← pronostico_solar.ipynb
├── artefactos/   ← 6 archivos (2 .parquet, 3 .png, 1 .json)
├── README.md   CLAUDE.md   CONFIG.md   ESTADO.md   PUBLICAR.md
├── DEPENDENCIAS_FASE1.md   FASE2_COSTO_DEL_ERROR.md   LICENCIAS.md
├── LICENSE   pyproject.toml   pytest.ini   requirements-banco.txt
```

**Ojo con dos carpetas que empiezan con punto** (`.github` y `.gitignore`):
en Windows y en Mac están ocultas por defecto. En el explorador active
«mostrar archivos ocultos» para confirmar que llegaron. Si falta `.gitignore`,
el repositorio se llena de basura; si falta `.github`, no corren las pruebas
automáticas.

### A2. Cambiar la URL en dos archivos

Hay que reemplazar un texto en dos archivos. Ábralos con el Bloc de notas,
TextEdit o VS Code y use **Buscar y reemplazar**:

| Buscar | Reemplazar por |
|---|---|
| `<usuario>/pronostico-solar` | `orozcoig/pronostico-solar` |

- En **`README.md`** aparece **1 vez**.
- En **`colab/pronostico_solar.ipynb`** aparece **1 vez**.

> **Importante:** en el cuaderno hay otra línea que dice `<usuario>` **sin
> barra** (`"<usuario>" in REPO`). **No la toque.** Es la que avisa con un
> mensaje claro si alguien abre el cuaderno sin configurar. Por eso se busca
> el texto completo `<usuario>/pronostico-solar` y no solo `<usuario>`.

Si prefiere consola, desde dentro de la carpeta:

```bash
sed -i "s|<usuario>/pronostico-solar|orozcoig/pronostico-solar|g" \
    README.md colab/pronostico_solar.ipynb
```

(En Mac: `sed -i ''` en lugar de `sed -i`.)

### A3. Comprobar que funciona antes de publicar

```bash
cd pronostico-solar
pip install -r requirements-banco.txt
python -m pytest tests/ -q -m "not lento"
```

**Debe decir `21 passed`.** Si no, no publique todavía: va a fallar igual en
GitHub y queda a la vista.

---

## PARTE B — Subirlo a GitHub

Dos caminos. **El primero es el más simple si tiene GitHub Desktop.**

### Camino 1 — GitHub Desktop (sin comandos)

1. Abra GitHub Desktop → menú **File → Add local repository**.
2. Elija la carpeta `pronostico-solar`. Le va a decir que no es un repositorio
   todavía y le ofrece **«create a repository»**: acepte.
3. En la ventana que aparece deje el nombre `pronostico-solar`. **No marque**
   «Initialize with README» ni elija licencia: ya los tiene.
4. Abajo a la izquierda escriba el mensaje
   `Banco de pruebas y motor de pronóstico operativo solar` y pulse
   **Commit to main**.
5. Arriba pulse **Publish repository**.
   - Desmarque **«Keep this code private»** si quiere que Colab lo abra sin
     pedir contraseña. Si lo deja privado, Colab no va a poder clonarlo.
6. Listo. Ya está en `https://github.com/orozcoig/pronostico-solar`.

### Camino 2 — Consola

1. En **github.com** → botón **New** → nombre `pronostico-solar` →
   **sin** README, **sin** .gitignore, **sin** licencia → **Create**.
2. En su PC, dentro de la carpeta:

```bash
git init
git add .
git status          # revise que NO aparezcan __pycache__ ni .pytest_cache
git commit -m "Banco de pruebas y motor de pronóstico operativo solar"
git branch -M main
git remote add origin https://github.com/orozcoig/pronostico-solar.git
git push -u origin main
```

---

## PARTE C — Comprobar

### C1. Que los artefactos subieron

Abra `https://github.com/orozcoig/pronostico-solar/tree/main/artefactos`

**Deben verse 6 archivos.** Si la carpeta está vacía o no existe, el cuaderno
no va a abrir. Solución: en la consola, `git add -f artefactos/` y vuelva a
subir.

### C2. Que las pruebas automáticas pasan

Abra `https://github.com/orozcoig/pronostico-solar/actions`

El trabajo *Banco sintético* arranca solo y debe quedar en verde en unos
minutos.

---

## PARTE D — Abrir el cuaderno en Colab

**No hay que crear ni subir nada a Colab.** El cuaderno ya existe en el
repositorio. Se abre con este enlace:

```
https://colab.research.google.com/github/orozcoig/pronostico-solar/blob/main/colab/pronostico_solar.ipynb
```

Ábralo y use **Entorno de ejecución → Ejecutar todo**.

Debe tardar **segundos**, no minutos: el cuaderno no entrena nada, solo lee los
artefactos que ya subió.

En el `README.md` quedó un botón **«Abrir en Colab»** que lleva al mismo sitio,
así que desde la portada del repositorio se abre con un clic.

---

## Qué va a ver

Los artefactos corresponden a la planta ficticia del encargo:

| | |
|---|---|
| Ubicación | Medellín, 6,25 N / 75,57 W |
| Capacidad | 500 kWp DC / 400 kW AC |
| Montaje | inclinación 15°, azimut 180°, estructura fija |
| Evaluación | 144 días no vistos por el modelo |
| Error | 47,7 kW de MAE, el 28,9 % de la generación media diurna |
| Incertidumbre | banda de 244 kW, el 61 % de la capacidad |

El cuaderno tiene cinco secciones: la gráfica de pronóstico contra real, la
lectura en lenguaje de negocio, el diagnóstico automático, cómo cargar datos
propios, y qué falta por decidir.

**Si quiere cambiar la planta** —otra ubicación, otra capacidad, otra
inclinación—, se edita `banco/sitios.py` y se regenera todo con un comando:

```bash
python -m banco.generar_todo              # 24 meses, unos 6 minutos
python -m banco.generar_todo --rapido     # 4 meses, 30 segundos, solo para probar
```

Eso reescribe la carpeta `artefactos/`; después hay que volver a subirla a
GitHub. **La opción `--rapido` da números distintos a propósito** (menos
historia): sirve para comprobar que el pipeline corre, no para citar cifras.

---

## Si algo sale mal

| Lo que ve | Qué pasó |
|---|---|
| `Falta configurar REPO...` | No hizo el paso A2, o lo hizo solo en un archivo |
| `No encuentro artefactos en...` | La carpeta `artefactos/` no subió (ver C1) |
| Colab pide autenticación | El repositorio quedó privado. Hágalo público en Settings |
| El cuaderno tarda minutos | Está regenerando algo. Revise que los `.parquet` estén en GitHub |
| En GitHub aparece `__pycache__` | Faltó el `.gitignore`. Bórrelo del repositorio y vuelva a subir |
| Las pruebas fallan en Actions pero pasan en su PC | Versiones distintas de librerías. Fije versiones exactas en `requirements-banco.txt` |
